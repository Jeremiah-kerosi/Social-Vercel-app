import React from 'react';

const UpdateProfile = () => {
    return (
        <div>
            
        </div>
    );
}

export default UpdateProfile;
