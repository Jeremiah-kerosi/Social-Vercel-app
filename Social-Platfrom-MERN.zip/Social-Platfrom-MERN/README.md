# Social-Platfrom-MERN
This is a social platform built using the MERN stack (MongoDB, Express, React, Node.js). It is designed to be similar to Twitter, with features such as:

- User authentication and authorization
- Posting and viewing tweets
- Following and unfollowing other users
- Searching for tweets and users
- Like
- User profile customization
- Real-time updates using web sockets
# Technologies Used
- MongoDB
- Express
- React
- Node.js
- Socket.io
- JSON Web Tokens
- bcrypt

![Screenshot from 2023-03-06 12-27-01](https://user-images.githubusercontent.com/87173929/223072961-6183be18-1865-441c-8ec0-62a104b531c9.png)
# Contributing
If you find any bugs or want to contribute to the project, please feel free to submit an issue or a pull request.

# License
This project is licensed under the MIT License
Demo https://social-sharkztech.vercel.app/
